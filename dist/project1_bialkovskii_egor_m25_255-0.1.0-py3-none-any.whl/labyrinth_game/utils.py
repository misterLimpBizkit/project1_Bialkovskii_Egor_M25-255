import math

from labyrinth_game.constants import COMMANDS, ROOMS


def describe_current_room(game_state):
    """
    Выводит название комнаты, следом описание, список предметов,
    доступные выходы и сообщение о наличии загадокю

    Args: словарь game_state

    Returns: все свойства комнаты
    """
    the_room = game_state['current_room']
    print(f'{the_room.upper():=^75}')
    print(ROOMS[the_room]['description'])
    if ROOMS[the_room]['items'] == []:
        print('В комнате нет ничего полезного')
    else:
        print(f'Заметные предметы: {", ".join(ROOMS[the_room]["items"])}')
    print(f'Выходы: {", ".join(ROOMS[the_room]["exits"])}')
    if ROOMS[the_room]['puzzle']:
        print("Кажется, здесь есть загадка (используйте команду solve).")
    print('='*75)


def solve_puzzle(game_state):
    """
    Проверяет есть ли в комнтае загадка, если есть - просит игрока решить ее

    Args: game_state

    Returns: дает игроку награду и убирает загадку из комнтаы
    """
    current_room = game_state['current_room']
    puzzles_in_the_room = ROOMS[current_room]['puzzle']

    if not puzzles_in_the_room:
        print("В этой комнате нет загадки.")
        return game_state

    question, right_answer, reward = puzzles_in_the_room

    alternative_answers = {
        '10': ['десять', 'ten'],
        'fat_ginger_cat': ['толстый рыжий кот', 'толстый кот']
    }

    correct_answers = [right_answer] + alternative_answers.get(right_answer, [])

    print(question)
    answer = input('Ваш ответ: ').strip().lower()
    
    if answer not in correct_answers:
        print('Неверно. Попробуйте снова.')
        if current_room == 'trap_room':
            print("Неверный ответ активировал ловушку!")
            trigger_trap(game_state)
        return game_state

    if right_answer == 'fat_ginger_cat' and 'fat_ginger_cat' \
    not in game_state['player_inventory']:
        print('У вас нет толстого кота, подберите его.')
        return game_state

    print('Правильно!')
    print(f'Вы получаете: {reward}!')
    ROOMS[current_room]['puzzle'] = None
    if reward == 'Освобождение':
        return game_state
    game_state['player_inventory'].append(reward)
    
    return game_state


def attempt_open_treasure(game_state):
    """
    Проверяет есть ли в инвентаре treasure_key,
    если есть - открыввает сундук и игра заканчивается,
    если нет - просит решит загадку, если игрок согласится,

    Args: game_state

    Returns: либо конец игры либо ничего с выводом "Вы отсупаете от сундука"
    """
    inventory = game_state['player_inventory']
    if 'treasure_key' in inventory:
        print("Вы применяете ключ, и замок щёлкает. Сундук открыт!")
        ROOMS[game_state['current_room']]['puzzle'] = None
        print("В сундуке сокровище! Поздравляю, вы победили!")
        game_state['game_over'] = True
    else:
        print("Сундук заперт. Вы можете попробовать взломать его. Ввести код? (да/нет)")
        players_choice = input()
        if players_choice == 'да':
            puzzles_in_the_room = ROOMS[game_state['current_room']]['puzzle']
            players_answer = input(f'{puzzles_in_the_room[0]}:')
            right_answer_treasure_room = puzzles_in_the_room[1]
            if players_answer == right_answer_treasure_room:
                print('Код верный!В сундуке сокровище! Вы победили!')
                ROOMS[game_state['current_room']]['puzzle'] = None
                game_state['game_over'] = True
            else:
                print('Неправильно!')
        else:
            print('Вы отходите от сундука.')

    return game_state


def show_help():
    """
    Выводит список доступных команд с красивым форматированием
    """
    print("\nДоступные команды:")
    for command, description in COMMANDS.items():
        print(f"    {command:<16} - {description}")


def pseudo_random(seed, modulo):
      """
    Генерирует псевдослучайное число в диапазоне [0, modulo) на основе синуса
    
    Args: seed (int): начальное значение (например, количество шагов)
    modulo (int): верхняя граница диапазона (исключительно)
    
    Returns:
    int: псевдослучайное число от 0 до modulo-1
    """
      seed_sinus = math.sin(seed * 12.9898)
      multiplied = seed_sinus * 43758.5453
      part = multiplied - math.floor(multiplied)
      result = math.floor(part * modulo)

      return result

def trigger_trap(game_state):
    """
    Bмитирует срабатывание ловушки и должна приводить к
    негативным последствиям для игрока

    Args: game_state

    Returns: изменение инвентаря и game_state
    """
    print('Ловушка активирована! Пол стал дрожать...')
    player_inventory = game_state['player_inventory']
    seed = game_state['steps_taken']
    if player_inventory == []:
        EVENT_PROBABILITY = 10
        random_number = pseudo_random(seed, EVENT_PROBABILITY)
        if random_number < 3:
            print('Пол распался на части. Вы упали в бездну!')
            game_state['game_over'] = True
        else:
            print('Вы уцелели!')
    else:
        user_items = game_state['player_inventory']
        random_item = pseudo_random(seed, len(user_items))
        lost_item = user_items.pop(random_item)
        print(f'В суматохе вы потеряли {lost_item}')


    return game_state

def random_event(game_state):
    """
    Рассчитывает вероятность случайного события,
    потом случайно выбирает событие и 
    воспроизводит его

    Args: game_state

    Returns: событие
    """
    seed = game_state['steps_taken']
    EVENT_MODULO = 15
    event_probability = pseudo_random(seed, EVENT_MODULO)
    if event_probability == 2:
        EVENT_MODULO_2 = 3
        event_type = pseudo_random(seed + 1, EVENT_MODULO_2)
        if event_type == 0:
            print('Вы нашли монетку!')
            items_in_the_room = ROOMS[game_state['current_room']]['items']
            items_in_the_room.append('coin')
        elif event_type == 1:
            print('Вы слышите шорох...')
            if 'sword' in game_state['player_inventory']:
                print('Вы отпугнули существо своим мечом.')
            else:
                print('Вам нечем защищаться...')
                print('Вас съел ящер, нужен был меч для защиты.')
                game_state['game_over'] = True
        elif event_type == 2:
            if game_state['current_room'] == 'trap_room' and \
            'torch' not in game_state['player_inventory']:
                print('Вы чувствуете опасность...')
                trigger_trap(game_state)

    return game_state

        

            


