# project1_-Bialkovskii-Egor-M25-255
My first Python project. Maze game.
